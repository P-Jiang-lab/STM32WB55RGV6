#ifndef _Com_Del_h_
#define _Com_Del_h_

#include "sys.h"

extern u8 (*DDS_deal)(void);
void sys_begin(void);

#endif

