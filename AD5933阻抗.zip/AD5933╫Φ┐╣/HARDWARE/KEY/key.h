#ifndef __key_H
#define __key_H

#include "stm32f10x.h"

#define KEY1 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0)
#define KEY2 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)
#define KEY3 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2)
#define KEY4 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_3)
#define KEY5 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_4)
#define KEY6 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5)
#define KEY7 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)
#define KEY8 		GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)

#define KEY_VALUE_1 0x01
#define KEY_VALUE_2 0x02
#define KEY_VALUE_3 0x03
#define KEY_VALUE_4 0x04
#define KEY_VALUE_5 0x05
#define KEY_VALUE_6 0x06
#define KEY_VALUE_7 0x07
#define KEY_VALUE_8 0x08
#define KEY_NULL    0x0f

//���峤������TICK�����Լ����������TICK��
#define KEY_SHORT_PERIOD 		10
#define KEY_LONG_PERIOD     	5000
#define KEY_CONTINUE_PERIOD 	1

//���尴������ֵ״̬�����£��������������ͷţ�
#define KEY_DOWN     0x80
#define KEY_LONG     0x40
#define KEY_CONTINUE 0x20
#define KEY_UP       0x10

//���尴��״̬
#define KEY_STATE_INIT     0
#define KEY_STATE_WOBBLE   1
#define KEY_STATE_PRESS    2
#define KEY_STATE_LONG     3
#define KEY_STATE_CONTINUE 4
#define KEY_STATE_RELEASE  5

extern uint8_t key_value;
extern volatile uint8_t menu_index,submenu_index;
extern uint8_t key_update_flag;

void key_init(void);
void key_process(void);
void key_handle(void);

#endif
