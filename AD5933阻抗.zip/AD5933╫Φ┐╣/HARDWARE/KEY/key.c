#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "key.h"
#include "flag.h"

uint8_t key_value = 0xff;
uint8_t volatile menu_index = 0,submenu_index = 0; //��ͨ����ʾ����
uint8_t key_update_flag = 0;

void key_init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);	 //ʹ��PB�˿�ʱ��
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | 
									GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;	//�˿�����
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //��������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; //IO���ٶ�Ϊ50MHz
	GPIO_Init(GPIOB, &GPIO_InitStructure); //�����趨������ʼ��
}

uint8_t key_scan(void)
{	
	if(KEY1 == 0) return KEY_VALUE_1;
	if(KEY2 == 0) return KEY_VALUE_2;
	if(KEY3 == 0) return KEY_VALUE_3;
	if(KEY4 == 0) return KEY_VALUE_4;
	if(KEY5 == 0) return KEY_VALUE_5;
	if(KEY6 == 0) return KEY_VALUE_6;
	if(KEY7 == 0) return KEY_VALUE_7;
	if(KEY8 == 0) return KEY_VALUE_8;
	return KEY_NULL;
}

void get_key(uint8_t *p_key_value)
{
		static uint8_t s_key_state = KEY_STATE_INIT;    
		static uint16_t s_key_short_time_count = 0; //�̰�������ʱ 
		static uint16_t s_key_long_time_count = 0;  //������ʱ
		static uint8_t s_key_short_flag = 0;  //�̰���׼λ
		static uint8_t s_key_long_flag = 0;   //������׼λ   
		static uint8_t s_last_key = KEY_NULL; //���水���ͷ�ʱ��ļ�ֵ
	uint8_t key_temp = KEY_NULL;

	key_temp = key_scan(); //��ȡ��ֵ

	switch(s_key_state)
	{
		case KEY_STATE_INIT:
		{
			if (KEY_NULL != (key_temp))
			{
				s_key_state = KEY_STATE_WOBBLE;
			}
		}
		break;

		case KEY_STATE_WOBBLE: //����
		{
			s_key_state = KEY_STATE_PRESS;
		}
		break;

		case KEY_STATE_PRESS:
		{
			if (KEY_NULL != (key_temp))
			{
                if (++s_key_short_time_count > KEY_SHORT_PERIOD)                  
                {  
                    s_key_short_time_count = 0;                
                    s_key_short_flag = 1; //��������                
                    s_last_key = key_temp;//�����ֵ���Ա����ͷŰ���״̬���ؼ�ֵ
                    s_key_state = KEY_STATE_LONG;
                }
			}
			else 
			{
                s_key_short_time_count = 0; 
				s_key_state = KEY_STATE_INIT;
			}			
		}
		break;

		case KEY_STATE_LONG:
		{
			if (KEY_NULL != (key_temp))
			{
				if (++s_key_long_time_count > KEY_LONG_PERIOD)
				{
					s_key_long_time_count = 0;
                    s_key_long_flag = 1;
					key_temp |= KEY_LONG; //�����¼�����
					s_key_state = KEY_STATE_CONTINUE;
				}
			}
			else
			{
				s_key_state = KEY_STATE_RELEASE;
			}
		}
		break;

		case KEY_STATE_CONTINUE:
		{
			if (KEY_NULL != (key_temp))
			{
				if (++s_key_long_time_count > KEY_CONTINUE_PERIOD)
				{
					s_key_long_time_count = 0;
					key_temp |= KEY_CONTINUE; //�����¼�����
				}
			}
			else
			{
				s_key_state = KEY_STATE_RELEASE;
			}
		}
		break;

		case KEY_STATE_RELEASE:
		{
            if(s_key_long_flag == 0 && s_key_short_flag == 1)
            {
                s_last_key |= KEY_DOWN; //��������
                s_key_short_flag = 0;
            }
            else
            {
                s_last_key &= ~KEY_DOWN;    //����ʱ������̰���־
            }
			s_last_key |= KEY_UP;
            s_key_long_flag = 0;    //���������־λ
			key_temp = s_last_key;
            s_key_short_time_count = 0;   //��ն̰�ʱ�����
            s_key_long_time_count = 0;   //��ճ���ʱ�����
			s_key_state = KEY_STATE_INIT;
		}
		break;
		default: break;
	}
	*p_key_value = key_temp; //���ؼ�ֵ
}

void key_process(void)
{
	key_value = 0xff;
	get_key(&key_value);
	
	if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_1))
	{
		flag_set(&key_flag,KEY_1);
		key_update_flag = 1;
	}	
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_2))
	{
		flag_set(&key_flag,KEY_2);
		key_update_flag = 1;
	}	
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_3))
	{
		flag_set(&key_flag,KEY_3);
		key_update_flag = 1;
	}	
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_4))
	{
		flag_set(&key_flag,KEY_4);
		key_update_flag = 1;
	}	
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_5))
	{
		flag_set(&key_flag,KEY_5);
		key_update_flag = 1;
	}					
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_6))
	{
		flag_set(&key_flag,KEY_6);
		key_update_flag = 1;
	}		
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_7))
	{
		flag_set(&key_flag,KEY_7);
		key_update_flag = 1;
	}	
	else if(key_value == (KEY_DOWN | KEY_UP | KEY_VALUE_8))
	{
		flag_set(&key_flag,KEY_8);
		key_update_flag = 1;
	}
	else{}
}

void key_handle(void)
{
	if(flag_get(&key_flag,KEY_1))
	{
		flag_clr(&key_flag,KEY_1);
		menu_index = 0;
		submenu_index = 0;
	}	
	else if(flag_get(&key_flag,KEY_2))
	{
		flag_clr(&key_flag,KEY_2);
		if(menu_index == 0) menu_index = 1;
	}
	else if(flag_get(&key_flag,KEY_3))
	{
		flag_clr(&key_flag,KEY_3);
		if(menu_index == 0) menu_index = 2;
	}
	else if(flag_get(&key_flag,KEY_4))
	{
		flag_clr(&key_flag,KEY_4);
		if(menu_index == 0) menu_index = 3;
	}
	else if(flag_get(&key_flag,KEY_5))
	{
		flag_clr(&key_flag,KEY_5);
		if(menu_index == 0) menu_index = 4;
	}
	else if(flag_get(&key_flag,KEY_6))
	{
		flag_clr(&key_flag,KEY_6);
		if(menu_index != 0)
		{
			if(submenu_index < 2)submenu_index++;
		}
	}
	else if(flag_get(&key_flag,KEY_7))
	{
		flag_clr(&key_flag,KEY_7);
		if(menu_index != 0)
		{
			if(submenu_index > 0) submenu_index--;
		}
	}
}

