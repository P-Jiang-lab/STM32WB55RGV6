#ifndef __FLAG_H
#define __FLAG_H

#include "sys.h"

#define KEY_1		0x0001
#define KEY_2		0x0002
#define KEY_3		0x0004
#define KEY_4		0x0008
#define KEY_5		0x0010
#define KEY_6		0x0020
#define KEY_7		0x0040
#define KEY_8		0x0080

extern uint16_t key_flag;

void flag_init(void);
void flag_set(uint16_t *flag,uint16_t bit_mask);
void flag_clr(uint16_t *flag,uint16_t bit_mask);
uint8_t flag_get(uint16_t *flag,uint16_t bit_mask);

#endif
