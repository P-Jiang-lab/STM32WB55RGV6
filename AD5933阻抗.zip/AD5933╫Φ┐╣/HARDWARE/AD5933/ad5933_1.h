#ifndef _AD5933_CH1_h_
#define _AD5933_CH1_h_

#include "sys.h"
#include "delay.h"

#include <math.h>
#define uint unsigned int



#define AD5933_SYS_Init					(1)<<12
#define AD5933_Begin_Fre_Scan		(2)<<12
#define AD5933_Fre_UP						(3)<<12
#define AD5933_Fre_Rep					(4)<<12
#define AD5933_Get_Temp					(9)<<12
#define AD5933_Sleep						(10)<<12
#define AD5933_Standby					(11)<<12

#define AD5933_OUTPUT_2V				(0)<<9
#define AD5933_OUTPUT_1V				(3)<<9
#define AD5933_OUTPUT_400mV			(2)<<9
#define AD5933_OUTPUT_200mV			(1)<<9

#define AD5933_Gain_1						(1)<<8
#define AD5933_Gain_5						(0)<<8

#define AD5933_IN_MCLK					(0)<<3
#define AD5933_OUT_MCLK					(1)<<3

#define AD5933_Reset						(1)<<4


extern float R1;

//���庯��

void AD5933_Init_Ch1();
static float Scale_imp (u8 *SValue,u8 *IValue,u8 *NValue,u8 *CValue);
static u16 AD5933_Tempter(void);
static float Get_resistance(u16 num);
static float AD5933_Sweep (float Fre_Begin,float Fre_UP,u16 UP_Num,u16 OUTPUT_Vatage,u16 Gain,u16 SWeep_Rep);
float DA5933_Get_Rs_Ch1(void);
static float DA5933_Get_Cap(float Fre);
static float DA5933_Get_L(float Fre);
static float DA5933_Dat_Cap_1(float Fre);
static void Maopao_Paixu(float *dat, u16 leng);
static void Fre_To_Hex(float fre,u8 *buf);


#endif
