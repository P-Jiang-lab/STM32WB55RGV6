
// #include "delay.h"
// #include "lcd.h"
// #include "stdlib.h"
// #include "oledfont.h"  	 
// #include "chinese.h"
// u8 LCD_GRAM[128][8];
// /*锟斤拷始锟斤拷LCD_GPIO*/
// void LCD_GPIO_Init(void)
// {
// 	GPIO_InitTypeDef  GPIO_InitStructure;

// 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOD, ENABLE);	 //使锟斤拷PE锟剿匡拷时锟斤拷

// 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;		
// 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //锟斤拷锟斤拷锟斤拷锟�
// 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO锟斤拷锟劫讹拷为50MHz
// 	GPIO_Init(GPIOB, &GPIO_InitStructure);					 //锟斤拷锟斤拷锟借定锟斤拷锟斤拷锟斤拷始锟斤拷GPIOE
// 	GPIO_SetBits(GPIOB,GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);						 //PBE 锟斤拷锟斤拷锟�
	
// 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;		
// 	GPIO_Init(GPIOD, &GPIO_InitStructure);					 //锟斤拷锟斤拷锟借定锟斤拷锟斤拷锟斤拷始锟斤拷GPIOE
// 	GPIO_SetBits(GPIOD,GPIO_Pin_2);						 //PBE 锟斤拷锟斤拷锟�

// }

// void LCD_GPIO_Init(void)
// {
// 	GPIO_InitTypeDef  GPIO_InitStructure;

// 	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOD, ENABLE);	 //使锟斤拷PE锟剿匡拷时锟斤拷

// 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;		
// 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //锟斤拷锟斤拷锟斤拷锟�
// 	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO锟斤拷锟劫讹拷为50MHz
// 	GPIO_Init(GPIOB, &GPIO_InitStructure);					 //锟斤拷锟斤拷锟借定锟斤拷锟斤拷锟斤拷始锟斤拷GPIOE
// 	GPIO_SetBits(GPIOB,GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);						 //PBE 锟斤拷锟斤拷锟�
	
// 	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;		
// 	GPIO_Init(GPIOD, &GPIO_InitStructure);					 //锟斤拷锟斤拷锟借定锟斤拷锟斤拷锟斤拷始锟斤拷GPIOE
// 	GPIO_SetBits(GPIOD,GPIO_Pin_2);						 //PBE 锟斤拷锟斤拷锟�

// }


// /*写指锟筋到 LCD 模锟斤拷*/
// void transfer_command(int data1)
// {
// 	char i;
	
// 	cs1=0;
// 	rs=0;
	
// 	for(i=0;i<8;i++)
// 	{
// 		sclk=0;
// 		if(data1&0x80) sid=1;
// 		else sid=0;
// 		sclk=1;
// 		data1=data1<<=1;
// 	}
// }

// /*写锟斤拷锟捷碉拷 LCD 模锟斤拷*/
// void transfer_data(int data1)
// {
// 	char i;
	
// 	cs1=0;
// 	rs=1;
	
// 	for(i=0;i<8;i++)
// 	{
// 		sclk=0;
// 		if(data1&0x80) sid=1;
// 		else sid=0;
// 		sclk=1;
// 		data1=data1<<=1;
// 	}
// }

// /*LCD 模锟斤拷锟绞硷拷锟�*/
// void initial_lcd(void)
// {
// 	LCD_GPIO_Init(); /*GPIO锟斤拷始锟斤拷*/
	
// 	cs1=0;
// 	reset=0; /*锟酵碉拷平锟斤拷位*/
// 	delay_ms(100);
// 	reset=1; /*锟斤拷位锟斤拷锟�*/
// 	delay_ms(20);
// 	transfer_command(0xe2); /*锟斤拷锟斤拷位*/
// 	delay_ms(5);
// 	transfer_command(0x2c); /*锟斤拷压锟斤拷锟斤拷 1*/
// 	delay_ms(5);
// 	transfer_command(0x2e); /*锟斤拷压锟斤拷锟斤拷 2*/
// 	delay_ms(5);
// 	transfer_command(0x2f); /*锟斤拷压锟斤拷锟斤拷 3*/
// 	delay_ms(5);
// 	transfer_command(0x23); /*锟街碉拷锟皆比讹拷,锟斤拷锟斤拷锟矫凤拷围 0x20~0x27*/
// 	transfer_command(0x81); /*微锟斤拷锟皆比讹拷*/
// 	transfer_command(0x28); /*0x1a,微锟斤拷锟皆比度碉拷值,锟斤拷锟斤拷锟矫凤拷围 0x00~0x3f*/
// 	transfer_command(0xa2); /*1/9 偏压锟斤拷(bias)*/
// 	transfer_command(0xc8); /*锟斤拷扫锟斤拷顺锟斤拷:锟斤拷锟较碉拷锟斤拷*/
// 	transfer_command(0xa0); /*锟斤拷扫锟斤拷顺锟斤拷:锟斤拷锟斤拷锟斤拷*/
// //	transfer_command(0xc0); /*锟斤拷扫锟斤拷顺锟斤拷:锟斤拷锟较碉拷锟斤拷*/
// //	transfer_command(0xa1); /*锟斤拷扫锟斤拷顺锟斤拷:锟斤拷锟斤拷锟斤拷*/
// 	transfer_command(0x40); /*锟斤拷始锟斤拷:锟斤拷一锟叫匡拷始*/
// 	transfer_command(0xaf); /*锟斤拷锟斤拷示*/
// 	cs1=1;
// }

// /*锟斤拷锟斤拷LCD锟斤拷址*/
// void lcd_address(u8 page,u8 column)
// {
// 	cs1=0;
// 	column=column;  //锟斤拷锟斤拷平锟斤拷锟斤拷说锟侥碉拷 1 锟斤拷,锟斤拷 LCD 锟斤拷锟斤拷 IC 锟斤拷锟角碉拷 0 锟斤拷.锟斤拷锟斤拷锟斤拷锟斤拷锟饺� 1.
// 	page=page;
// 	//锟斤拷锟斤拷页锟斤拷址.每页锟角碉拷 8 锟斤拷.一锟斤拷锟斤拷锟斤拷锟� 64 锟叫憋拷锟街筹拷 8 锟斤拷页. 锟斤拷锟斤拷平锟斤拷锟斤拷说锟侥碉拷 1 页,锟斤拷 LCD 锟斤拷锟斤拷 IC 锟斤拷锟角碉拷 0 页.锟斤拷锟斤拷锟斤拷锟斤拷锟饺� 1.*/
// 	transfer_command(0xb0+page); 
// 	transfer_command(((column>>4)&0x0f)+0x10); //锟斤拷锟斤拷锟叫碉拷址锟侥革拷 4 位
// 	transfer_command(column&0x0f);  //锟斤拷锟斤拷锟叫碉拷址锟侥碉拷 4 位
// }

// //锟斤拷锟斤拷锟皆存到LCD		 
// void LCD_Refresh_Gram(void)
// {
// 	u8 i,n;		
// 	cs1=0;
// 	for(i=0;i<8;i++)  
// 	{
// 		lcd_address(i,0);
// 		for(n=0;n<128;n++)
// 		{
// 			transfer_data(LCD_GRAM[n][i]);
// 		}
// 	}
// 	cs1=1;
// }
// //锟斤拷锟斤拷锟斤拷锟斤拷,锟斤拷锟斤拷锟斤拷,锟斤拷锟斤拷锟斤拷幕锟角猴拷色锟斤拷!锟斤拷没锟斤拷锟斤拷一锟斤拷!!!	  
// void LCD_Clear(void)
// {
// 	u8 i,n;  
// 	cs1=0;
// 	for(i=0;i<8;i++)for(n=0;n<128;n++)LCD_GRAM[n][i]=0x00;  
// 	cs1=1;
// 	LCD_Refresh_Gram();//锟斤拷锟斤拷锟斤拷示
// }
// void LCD_draw_Square(u8 x1,u8 y1,u8 x2,u8 y2)
// {
// 	LCD_Fill(x1,y1,x1,y2,1);
// 	LCD_Fill(x1,y1,x2,y1,1);
// 	LCD_Fill(x1,y2,x2,y2,1);
// 	LCD_Fill(x2,y1,x2,y2,1);
// }

// //锟斤拷锟斤拷 
// //x:0~127
// //y:0~63
// //t:1 锟斤拷锟� 0,锟斤拷锟�
// void LCD_draw_Point(u8 x,u8 y,u8 t)
// {
// 	u8 pos,bx,temp=0;
// 	if(x>127||y>63)return;//锟斤拷锟斤拷锟斤拷围锟斤拷.
// //	cs1=0;
// 	pos=y/8;
// 	bx=y%8;
// 	temp=1<<bx;
// 	if(t)LCD_GRAM[x][pos]|=temp;
// 	else LCD_GRAM[x][pos]&=~temp;
// //	cs1=1;
// }
// void LCD_Move_DrawPoint(u8 x,u8 y,u8 t)
// {
// 	u8 pos,bx,temp=0;
// 	if(x>127)	x -= 127;
// 	if(y>63)	y -= 63;
// 	pos=y/8;
// 	bx=y%8;
// 	temp=1<<(bx);
// 	if(t)LCD_GRAM[x][pos]|=temp;
// 	else LCD_GRAM[x][pos]&=~temp;	    
// }
// void LCD_Fill(u8 x1,u8 y1,u8 x2,u8 y2,u8 dot)  
// {
// 	u8 x,y;  
// 	for(x=x1;x<=x2;x++)
// 	{
// 		for(y=y1;y<=y2;y++)LCD_draw_Point(x,y,dot);
// 	}
// //	LCD_Refresh_Gram();//锟斤拷锟斤拷锟斤拷示
// }

// //x1,y1,x2,y2 锟斤拷锟斤拷锟斤拷锟侥对斤拷锟斤拷锟斤拷
// //确锟斤拷x1<=x2;y1<=y2 0<=x1<=127 0<=y1<=63	 	 
// //dot:0,锟斤拷锟�;1,锟斤拷锟�	  

// void Set_Point(u8 x,u8 y)
// {
// 	static u8 time=0,set=5,xbuf=0,ybuf=0;
	
// 	time++;
// 	if(xbuf!=x || ybuf!=y)	LCD_Fill(xbuf,ybuf,xbuf,ybuf+16,0);
// 	if(time < set)
// 	{
// 		LCD_Fill(x,y,x,y+16,1);
// 	}else if(time < set*2)
// 	{
// 		LCD_Fill(x,y,x,y+16,0);
// 	}else time=0;
// 	xbuf=x;
// 	ybuf=y;
// }

// //锟斤拷指锟斤拷位锟斤拷锟斤拷示一锟斤拷锟街凤拷,锟斤拷锟斤拷锟斤拷锟斤拷锟街凤拷
// //x:0~127
// //y:0~63
// //mode:0,锟斤拷锟斤拷锟斤拷示;1,锟斤拷锟斤拷锟斤拷示
// //size:选锟斤拷锟斤拷锟斤拷 16/12
// void LCD_ShowChar(u8 x,u8 y,u8 chr,u8 size,u8 mode)
// {
// 	u8 temp,t,t1;
// 	u8 y0=y;
// 	chr=chr-' ';//锟矫碉拷偏锟狡猴拷锟街�				   
//     for(t=0;t<size;t++)
//     {   
// 			if(size==12)temp=asc2_1206[chr][t];  //锟斤拷锟斤拷1206锟斤拷锟斤拷
// 			else temp=asc2_1608[chr][t];		 //锟斤拷锟斤拷1608锟斤拷锟斤拷 	                          
// 			for(t1=0;t1<8;t1++)
// 			{
// 				if(temp&0x80)LCD_draw_Point(x,y,mode);
// 				else LCD_draw_Point(x,y,!mode);
// 				temp<<=1;
// 				y++;
// 				if((y-y0)==size)
// 				{
// 					y=y0;
// 					x++;
// 					break;
// 				}
// 			}  	 
//     }
// }
// void LCD_Show_chineseChar(u8 x,u8 y,char *chr, u8 mode)
// {
// 	u8 temp,t,t1;
// 	u8 y0=y;		
	
// 	for(t=0;t<32;t++)
// 	{
// 		temp = *chr;
// 		for(t1=0;t1<8;t1++)
// 		{
// 			if(temp&0x80)
// 				LCD_Move_DrawPoint(x,y,mode);
// 			else
// 			LCD_Move_DrawPoint(x,y,!mode);
// 			temp<<=1;
// 			y++;
// 			if((y-y0)==16)
// 			{
// 				y=y0;
// 				x++;
// 				break;
// 			}
// 		} 
// 		chr++;
// 	}  
// }
// void	WriteA_Chinese(u8 mode,unsigned char x, unsigned char y, const u8 *s)
// {
// 	unsigned char j;

// 	if (x > 127) return;
// 	if (y > 63) return;

// 	for (j = 0; j < sizeof(GB_16)/34;j++)
// 	{
// 		if(s[0] == (char)GB_16[j].Index[0] && s[1] == (char)GB_16[j].Index[1])
// 		{
// 			LCD_Show_chineseChar(x, y, &GB_16[j].Msk[0], mode);
// 			x+=16;
// 			break;
// 		}
// 	}
// }
// //锟斤拷示锟街凤拷锟斤拷
// //x,y:锟斤拷锟斤拷锟斤拷锟�  
// //*p:锟街凤拷锟斤拷锟斤拷始锟斤拷址
// //锟斤拷16锟斤拷锟斤拷
// void LCD_Show_CEStr(u16 x0,u16 y0, u8 *pp)
// {
// 	LCD_ShowAllString(1,x0,y0*8,pp);
// }
// void LCD_Show_ModeCEStr(u16 x0,u16 y0, u8 *pp, u8 show_mode)
// {
// 	LCD_ShowAllString(show_mode,x0,y0*8,pp);

// }
// void OLED_ShowString(u8 x,u8 y,u8 *chr)
// {
// 	LCD_ShowAllString(1,x,y*8,chr);

// }


// void LCD_ShowString(u8 mode,u8 x,u8 y,const u8 *p)
// {
// #define MAX_CHAR_POSX 122
// #define MAX_CHAR_POSY 58          
//     while(*p!='\0')
//     {       
//         if(x>MAX_CHAR_POSX){x=0;y+=16;}
//         if(y>MAX_CHAR_POSY){y=x=0;LCD_Clear();}
//         LCD_ShowChar(x,y,*p,16,mode);	 
//         x+=8;
//         p++;
//     }  
// }
// void LCD_ShowString_12(u8 mode,u8 x,u8 y,const u8 *p)
// {
// #define MAX_CHAR_POSX 122
// #define MAX_CHAR_POSY 58          
//     while(*p!='\0')
//     {
//         if(x>MAX_CHAR_POSX){x=0;y+=16;}
//         if(y>MAX_CHAR_POSY){y=x=0;LCD_Clear();}
//         LCD_ShowChar(x,y,*p,12,mode);	 
//         x+=8;
//         p++;
//     }  
// }
// void LCD_ShowAllString(u8 mode,u8 x,u8 y,const u8 *p)
// {
// #define MAX_CHAR_POSX 122
// #define MAX_CHAR_POSY 58          
//     while(*p!='\0')
//     {       
// 			if(x>MAX_CHAR_POSX)return;
// 			if(y>MAX_CHAR_POSY)return;
// 			if(*p>127)
// 			{
// 				WriteA_Chinese(mode,x,y,p);
// 				p+=2;
// 				x+=16;
// 			}else
// 			{
// 				LCD_ShowChar(x,y,*p,16,mode);
// 				x+=8;
// 				p++;				
// 			}
//     }  
// }	 

// void	Write_Chinese_String(u8 mode,unsigned char x, unsigned char y, char *s)
// {
// 	unsigned char i, j;

// 	if (x > 127) return;
// 	if (y > 63) return;
// 	for (i = 0; s[i] != '\0'; i+=2)
// 	{
// 		for (j = 0; j < sizeof(GB_16)/34;j++)
// 		{
// 			if(s[i] == (char)GB_16[j].Index[0] && s[i + 1] == (char)GB_16[j].Index[1])
// 			{
// 				LCD_Show_chineseChar(x, y, &GB_16[j].Msk[0], mode);
// 				x+=16;
// 				break;
// 			}
// 		}
// 	}
// }




// /***********************************************************
// * 锟斤拷锟斤拷锟斤拷锟狡ｏ拷LCD_DrawLine
// * 锟斤拷锟斤拷锟斤拷锟杰ｏ拷LCD锟斤拷锟竭猴拷锟斤拷
// *           锟斤拷诓锟斤拷锟�: x1,y1锟斤拷锟斤拷锟斤拷锟斤拷辏﹛2,y2锟斤拷锟秸碉拷锟斤拷锟疥）c(锟斤拷色)   
// *			锟斤拷锟节诧拷锟斤拷锟斤拷锟斤拷 
// ***********************************************************/

// // 锟斤拷锟斤拷锟斤拷锟斤拷 a 锟斤拷b 锟斤拷值    
// __inline void swap_int(u16 *a, u16 *b)   
// {    
//     *a ^= *b;    
//     *b ^= *a;    
//     *a ^= *b;    
// }    
  
// // Bresenham's line algorithm    
  
// void LCD_DrawLine(u16 x1, u16 y1, u16 x2, u16 y2, u8 c)   
// {        
//     u16 dx =abs( x2 - x1), // 水平锟斤拷锟斤拷   
//         dy =abs( y2 - y1), // 锟斤拷直锟斤拷锟斤拷   
//         yy = 0;    		   // 锟角讹拷锟角凤拷锟斤拷锟�45锟斤拷锟街�
  
// 	int ix ,    
//         iy,    
//         cx ,    
//         cy ,    
//         n2dy,    
//         n2dydx ,    
//         d ; 
//     if(dx < dy)  // 锟斤拷斜锟绞达拷锟斤拷 1 时锟斤拷dx锟斤拷dy 锟斤拷锟斤拷, 锟斤拷锟角度达拷锟斤拷45锟斤拷 
//     {    
//         yy = 1;              // 锟斤拷锟矫憋拷志位  
//         swap_int(&x1, &y1);  // 锟斤拷锟斤拷锟斤拷锟斤拷  
//         swap_int(&x2, &y2);    
//         swap_int(&dx, &dy);    
//     }        
//     ix = (x2 - x1) > 0 ? 1 : -1; // 锟叫讹拷锟角凤拷锟�1锟斤拷锟角硷拷一    
//     iy = (y2 - y1) > 0 ? 1 : -1;    
//     cx = x1;  //  x锟斤拷值  
//     cy = y1;  //  y锟斤拷值  
//     n2dy = dy * 2;    		 // 锟斤拷要锟饺较的革拷锟斤拷锟斤拷值
//     n2dydx = (dy - dx) * 2;    
//     d = dy * 2 - dx;     

// // 锟斤拷锟街憋拷锟斤拷锟� x 锟斤拷募薪谴锟斤拷锟�45锟斤拷    
//     if(yy)  
//     {   
//         while(cx != x2) // 锟斤拷锟斤拷锟角凤拷锏斤拷盏锟�  
//         {    
//             if(d < 0)  
//             {    
//                 d += n2dy;    
//             }   
//             else   
//             {    
//                 cy += iy;    
//                 d += n2dydx;    
//             }    
//             LCD_draw_Point( cy, cx, c); // 锟斤拷锟斤拷   
//             cx += ix;    
//         }    
//     }
  
// // 锟斤拷锟街憋拷锟斤拷锟� x 锟斤拷募薪锟叫★拷锟�45锟斤拷    
//     else   
//     {   
//         while(cx != x2)   
//         {    
//             if(d < 0)  
//             {    
//                 d += n2dy;    
//             }  
//             else   
//             {    
//                 cy += iy;    
//                 d += n2dydx;    
//             }    
//             LCD_draw_Point( cx, cy, c);    
//             cx += ix;    
//         }    
//     }    
// }   

// /**********************************************************
// * 锟斤拷锟斤拷锟斤拷锟狡ｏ拷LCD_DrawRectangle
// * 锟斤拷锟斤拷锟斤拷锟杰ｏ拷LCD锟斤拷锟斤拷锟轿猴拷锟斤拷
// *           锟斤拷诓锟斤拷锟�: x1,y1锟斤拷锟皆斤拷锟斤拷锟斤拷锟斤拷锟斤拷辏﹛2,y2锟斤拷锟皆斤拷锟斤拷锟秸碉拷锟斤拷锟疥）color(锟斤拷色)   
// *			锟斤拷锟节诧拷锟斤拷锟斤拷锟斤拷 
// ***********************************************************/

// void LCD_DrawRectangle(u16 x1, u16 y1, u16 x2, u16 y2, u8 color)
// {
// 	LCD_DrawLine(x1,y1,x2,y1,color);
// 	LCD_DrawLine(x1,y1,x1,y2,color);
// 	LCD_DrawLine(x1,y2,x2,y2,color);
// 	LCD_DrawLine(x2,y1,x2,y2,color);
// }

// /**********************************************************
// * 锟斤拷锟斤拷锟斤拷锟狡ｏ拷LCD_Drawcircle
// * 锟斤拷锟斤拷锟斤拷锟杰ｏ拷锟斤拷指锟斤拷位锟矫伙拷一锟斤拷指锟斤拷锟斤拷小锟斤拷圆
// *           锟斤拷诓锟斤拷锟�: (x,y)-(锟斤拷锟侥碉拷锟斤拷锟疥）r(锟诫径)
// *                     fill(为锟角凤拷锟斤拷锟�)   c(锟斤拷色)   
// *			锟斤拷锟节诧拷锟斤拷锟斤拷锟斤拷 
// ***********************************************************/
	  
// __inline void draw_circle_8( u16 xc, u16 yc, u16 x, u16 y, u8 c)   
// 	{    
// 	    // 锟斤拷锟斤拷 c 为锟斤拷色值    
// 	    LCD_draw_Point( xc + x, yc + y, c);    
// 	    LCD_draw_Point( xc - x, yc + y, c);    
// 	    LCD_draw_Point( xc + x, yc - y, c);   
// 	    LCD_draw_Point( xc - x, yc - y, c);
// 	    LCD_draw_Point( xc + y, yc + x, c);   
// 	    LCD_draw_Point( xc - y, yc + x, c);
// 	    LCD_draw_Point( xc + y, yc - x, c);
// 	    LCD_draw_Point( xc - y, yc - x, c);
// 	}       
// //Bresenham's circle algorithm    
// void LCD_Drawcircle( u16 xc, u16 yc, u16 r, u16 fill, u8 c)  
// 	{    
// 	    // (xc, yc) 为圆锟侥ｏ拷r 为锟诫径    
// 	    // fill 为锟角凤拷锟斤拷锟�    
// 	    // c 为锟斤拷色值       
// 	    // 锟斤拷锟皆诧拷锟酵计�锟缴硷拷锟斤拷锟斤拷锟解，直锟斤拷锟剿筹拷    
	  
// 	   int x = 0, y = r, yi, d;    
// 	       d = 3 - 2 * r; 

// //	    if(xc + r < 0 || xc - r >= 128 || yc + r < 0 || yc - r >= 64)   
// //	    {
// //	        return;  
// //	    }     
// 	    if(fill)  
// 	    {    
// 	        // 锟斤拷锟斤拷锟戒（锟斤拷实锟斤拷圆锟斤拷    
// 	        while(x <= y)   
// 	        {    
// 	            for(yi = x; yi <= y; yi ++)    
// 	            {  
// 	                draw_circle_8(xc, yc, x, yi, c);    
// 	            }  
// 	            if(d < 0)   
// 	            {    
// 	                d = d + 4 * x + 6;    
// 	            }   
// 	            else   
// 	            {    
// 	                d = d + 4 * (x - y);    
// 	                y --;    
// 	            }    
	  
// 	            x++;    
// 	        }    
// 	    }   
// 	    else   
// 	    {    
// 	        // 锟斤拷锟斤拷锟斤拷锟戒（锟斤拷锟斤拷锟斤拷圆锟斤拷    
// 	        while (x <= y)   
// 	        {    
// 	            draw_circle_8(xc, yc, x, y, c);    
// 	            if(d < 0)   
// 	            {    
// 	                d = d + 4 * x + 6;    
// 	            }   
// 	            else   
// 	            {    
// 	                d = d + 4 * (x - y);    
// 	                y --;    
// 	            }    
// 	            x ++;    
// 	        }    
// 	    }    
// 	}   





