#ifndef __TIMER_H
#define __TIMER_H

#include "sys.h"

extern uint8_t flag_1ms,flag_10ms,flag_100ms;

void TIM3_Init(u16 arr,u16 psc);
 
#endif
