#include "stm32_config.h"
// #include "task_manage.h"
#include "ad5933_1.h"
#include "ad5933_2.h"
#include "ad5933_3.h"
#include "ad5933_4.h"

#include "key.h"
#include "usart.h"
#include "oled.h"
#include "timer.h"
#include "flag.h"

#define UART1_DEBUG 0

char str[30];

/**********************************************************
                           
**********************************************************/

uint16_t extract_decimal(float num) {
    // ������������1000
    int temp = (int)(num * 1000);
    // ��ȡС�����ֲ�����
    return temp % 1000;
}

#define LINE_HIGHT 16

void show_data(int ch, float Rs)
{
	float R;
	uint16_t R1;
	uint16_t R2;
	uint8_t i = 0;
	#if(UART1_DEBUG==1)
	memset(str,0,30);
	printf("show_data Rs=%f\r\n",Rs);
	#endif
	
	if(Rs>15000000)
	{
		#if(UART1_DEBUG==1)
		sprintf(str,"   0L��  ",Rs/1000000); 
		#endif
		R = Rs/1000000;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
		OLED_ShowString(90, LINE_HIGHT*(ch-1), "L", 16, 1);
	}
	else if(Rs>1000000)
	{
		#if(UART1_DEBUG==1)
		sprintf(str,"%03.03fM��  ",Rs/1000000);
		#endif
		R = Rs/1000000;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
		OLED_ShowString(90, LINE_HIGHT*(ch-1), "M", 16, 1);
	}
	else if(Rs>1000)
	{
		#if(UART1_DEBUG==1)
		sprintf(str,"%03.03fK��  ",Rs/1000); 
		#endif
		R = Rs/1000;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
		OLED_ShowString(90, LINE_HIGHT*(ch-1), "K", 16, 1);
	}
	else if(Rs<1000)
	{
		#if(UART1_DEBUG==1)
		sprintf(str,"%03.03f��  ",Rs);  
		#endif
		R = Rs;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
	}

	#if(UART1_DEBUG==1)
	for(i = 0; i<30; i++)
	{
		USART_SendData(USART1, str[i]);
		delay_us(100);
	}
	delay_ms(100);
	#endif
	
	OLED_ShowString(0,(ch-1)*16,(u8 *)"CH",16,1);
	OLED_ShowChar(16,(ch-1)*16,ch+0x30,16,1);
	OLED_ShowNum(32, LINE_HIGHT*(ch-1), R1, 3, 16, 1); // ��������
	OLED_ShowString(56, LINE_HIGHT*(ch-1), (u8 *)".", 16, 1); // "."С����
	OLED_ShowNum(64, LINE_HIGHT*(ch-1), R2, 3, 16, 1); // С������
	OLED_ShowChinese(98,LINE_HIGHT*(ch-1),6,16,1);//��    
	OLED_Refresh();
}

void show_submenu_data(int ch, float Rs)
{
	float R;
	uint16_t R1;
	uint16_t R2;
	uint8_t i = 0;
	
	if(Rs>15000000)
	{
		R = Rs/1000000;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
		OLED_ShowString(102, 0, "L", 16, 1);
	}
	else if(Rs>1000000)
	{
		R = Rs/1000000;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
		OLED_ShowString(102, 0, "M", 16, 1);
	}
	else if(Rs>1000)
	{
		R = Rs/1000;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
		OLED_ShowString(102, 0, "K", 16, 1);
	}
	else if(Rs<1000)
	{ 
		R = Rs;
		R1 = (uint16_t)R;
		R2 = extract_decimal(R);
	}

	OLED_ShowNum(60, 0, R1, 3, 12, 1); // ��������
	OLED_ShowString(78, 0, (u8 *)".", 12, 1); // "."С����
	OLED_ShowNum(84, 0, R2, 3, 12, 1); // С������
	OLED_ShowChinese(110,0,6,16,1);//��    
	OLED_Refresh();
}
void display_handle(void)
{
	if(key_update_flag == 1)
	{
		key_update_flag = 0;
		OLED_Clear();
	}
	
	if(menu_index == 0)
	{
		show_data(1, R1);		
		show_data(2, R2);		
		show_data(3, R3);		
		show_data(4, R4);  
	}
	else
	{
		OLED_ShowString(0,0,(u8 *)"CH",12,1);
		OLED_ShowChar(12,0,menu_index+0x30,12,1);
		OLED_ShowString(20,0,(u8 *)"model",12,1);
		OLED_ShowChar(50,0,submenu_index+0x31,12,1);
		//OLED_Refresh();
		if(menu_index == 1) show_submenu_data(menu_index, R1);
		else if(menu_index == 2) show_submenu_data(menu_index, R2);
		else if(menu_index == 3) show_submenu_data(menu_index, R3);
		else if(menu_index == 4) show_submenu_data(menu_index, R4);
	}
}

void show_wave(u8 ch, float Rs)
{
	static int x=0;
	static u8 lastX,lastR, menuIndex=0,subMenuIndex=0;
	u8 R;
	
	if(menu_index==0)return;
	if(ch!=menu_index)return;
	if(Rs<0){x=0;return;}
	
	R = 64 - (int)Rs/10%50;
	if(menuIndex!=menu_index)
	{
		OLED_Clear();
		menuIndex = menu_index;
		lastX=0;
		x=0;
	}
	if(subMenuIndex!=submenu_index)
	{
		OLED_Clear();
		subMenuIndex = submenu_index;
		lastX=0;
		x=0;
	}
	if(x==0){
		OLED_Clear();
		OLED_DrawLine(x,R,x,R,1);
	}else{
		OLED_DrawLine(lastX,lastR,x,R,1);
	}
	
	//OLED_DrawWave(x,(int)Rs%50);
	//OLED_DrawPoint(x,(int)Rs%50,1);
	//OLED_Refresh();
	lastX=x;
	lastR=R;
	x=(x+1)%128;
	display_handle();
}


void power_on_display(void)
{
	uint8_t i;
	OLED_ShowString(24,0,(u8 *)"Welcome",16,1);
	OLED_ShowString(20,16,(u8 *)"OPENING...",16,1);
	for(i= 0;i < 6;i++)
	{
		OLED_ShowChinese(20+i*16,45,i,16,1);
	}
	OLED_Refresh();
	delay_ms(3000);
	OLED_Clear();
}


int main(void)
{
	float Rs;

	delay_init();
	MY_NVIC_PriorityGroup_Config(NVIC_PriorityGroup_2);	
	key_init();
	USARTx_Init(115200);
	TIM3_Init(999,71);      //��ʱ1ms
	AD5933_Init_Ch1();
	AD5933_Init_Ch2();
	AD5933_Init_Ch3();
	AD5933_Init_Ch4();

	OLED_Init();
	OLED_ColorTurn(0);
	OLED_DisplayTurn(0);
	LED_ON;
	power_on_display();
	flag_init();

			printf("Scale_imp: one time finished.\r\n");
		

	while (1)
	{
		DA5933_Get_Rs_1();
		DA5933_Get_Rs_2();
		DA5933_Get_Rs_3();
		DA5933_Get_Rs_4();
    display_handle();
	}
}

